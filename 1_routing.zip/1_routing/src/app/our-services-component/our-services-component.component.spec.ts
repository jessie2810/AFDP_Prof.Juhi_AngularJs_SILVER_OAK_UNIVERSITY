import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OurServicesComponentComponent } from './our-services-component.component';

describe('OurServicesComponentComponent', () => {
  let component: OurServicesComponentComponent;
  let fixture: ComponentFixture<OurServicesComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OurServicesComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OurServicesComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
