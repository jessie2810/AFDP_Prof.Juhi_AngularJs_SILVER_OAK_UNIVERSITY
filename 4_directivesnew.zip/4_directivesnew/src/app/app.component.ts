import { Component, OnInit } from '@angular/core';
import { Person, Persons } from './person';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  //ngModel Binding Demo
  currentItem!:String;

  //ngClass Binding Demo
  countryName!:String;

  persons = Persons;
  person: Person | null = this.persons[0];
  condition = false;
  logs: string[] = [];
  showSad = true;
  status = 'ready';
  
  ngOnInit() {
    this.currentItem="SilverOak";
    this.countryName="INDIA";
  }

  //Convert name into Uppercase and Return.
  setUppercaseName(name: string) {
    this.currentItem = name.toUpperCase();
  }

  //Convert name into Lowercase and Return.
  setLowercaseName(name: string) {
    this.currentItem = name.toLowerCase();
  }


  //users Array for ngClass and *ngFor demo.
  users=[
    'Juhi',
    'Jay',
    'Aishwarya',
    'Ujjaval'
  ]

  //ngClass component method.
  cssClassFunction(className:string):string{
    if(className==='NightMode'){
      return "cssNightModeClass" 
    }
    else{
      return "cssDayModeClass" 
    }
  }

  trackById(index: number, person: Person): number { return person.id; }
}



