import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponentComponent } from './home-component/home-component.component';
import { AboutComponentComponent } from './about-component/about-component.component';
import { ContactComponentComponent } from './contact-component/contact-component.component';
import { OurServicesComponentComponent } from './our-services-component/our-services-component.component';
import { SignUpComponentComponent } from './sign-up-component/sign-up-component.component';

const routes: Routes = [
  {path:'',component:HomeComponentComponent},
  {path:'AboutComponentComponent',component:AboutComponentComponent},
  {path:'ContactComponentComponent',component:ContactComponentComponent},
  {path:'OurServicesComponentComponent',component:OurServicesComponentComponent},
  {path:'SignUpComponentComponent',component:SignUpComponentComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
