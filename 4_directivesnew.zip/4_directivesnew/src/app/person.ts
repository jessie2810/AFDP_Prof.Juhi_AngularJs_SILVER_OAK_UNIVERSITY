export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Juhi', gender: 'Female'},
    { id: 2, name: 'Jay', gender: 'Male' },
    { id: 3, name: 'Aishwarya', gender: 'Female' },
    { id: 4, name: 'Ujjaval',gender: 'Male'}
  ];
  