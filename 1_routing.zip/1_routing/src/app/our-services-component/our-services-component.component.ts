import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-services-component',
  templateUrl: './our-services-component.component.html',
  styleUrls: ['./our-services-component.component.css']
})
export class OurServicesComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
