import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-component',
  templateUrl: './sign-up-component.component.html',
  styleUrls: ['./sign-up-component.component.css']
})
export class SignUpComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
